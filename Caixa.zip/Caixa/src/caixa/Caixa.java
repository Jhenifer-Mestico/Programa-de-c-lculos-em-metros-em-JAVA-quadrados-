/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package caixa;

/**
 *
 * @author Jhenifer
 */
import javax.swing.JOptionPane;
public class Caixa {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        float l, a, p, vol;
        l = Integer.parseInt(JOptionPane.showInputDialog(null, "Digite a largura em cm: ", "Dado", JOptionPane.INFORMATION_MESSAGE));
        a = Integer.parseInt(JOptionPane.showInputDialog(null, "Digite a altura em cm: ", "Dado", JOptionPane.INFORMATION_MESSAGE));
        p = Integer.parseInt(JOptionPane.showInputDialog(null, "Digite a profundidade em cm: ", "Dado", JOptionPane.INFORMATION_MESSAGE));
        
        vol=l*a*p;
        
        JOptionPane.showMessageDialog(null, "Volume é: "+ vol + JOptionPane.INFORMATION_MESSAGE);
    }
    
}
